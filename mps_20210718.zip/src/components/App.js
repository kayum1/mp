import React from 'react';
import Header from './Header';
import Nav from './Nav';
import Loading from './loadError';
import Stories from './stories';
import data from './data';
import Users from './../components/data.json';

const navItems = ['arts', 'books', 'fashion', 'food', 'movies', 'travel'];
const nytapi = 'jXsc2QdkjNLM9LiDrBYoalPGGy21A382';
// const URL = 'http://localhost:8085/data';
// const URL = `https://api.nytimes.com/svc/topstories/v2/${section}.json?api-key=${nytapi}`;
const sleep = (ms) => {
  setTimeout(function () {
    console.log('.... waiting ', ms);
  }, ms);
};

let filterItems = data.forEach((element) => {
  // if (element.section === 'business') {
  console.log(element.section);
  return element;
  //}
});

function App() {
  const [stories, setStories] = React.useState([]);
  const [loading, setLoading] = React.useState(false);
  const [section, setSection] = React.useState('arts');
  React.useEffect(() => {
    const url = new URL(window.location.href);
    const hash = url.hash.slice(1);
    if (hash !== 'undefined') {
      setSection(hash);
    } else {
      setSection('arts');
    }
  }, []);

  React.useEffect(() => {
    setLoading(true);

    <Loading />;
    fetch('./data.json', {
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
    })
      .then((response) => response.json())
      .then(function (myJson) {
        console.log(myJson);
      });
    //

    fetch('./data.json').then(function (data) {
      console.log('Here ', data);
    });

    // fetch(
    //   `https://api.nytimes.com/svc/topstories/v2/${section}.json?api-key=${nytapi}`
    // )
    //  fetch(URL)
    fetch('http://localhost:3000/data.json')
      .then(sleep(3000))
      .then((response) => response.json())
      .then((data) => {
        console.log(data); // .results);
        setStories(data); // .results);
      })
      .then(setLoading(false))
      .catch((error) => {
        console.log(error);
      });
  }, [section]);

  // const filterItems = data.filter((element) => element.section === 'business');

  // let filterItems = data.forEach((element) => {
  //   // if (element.section === 'business') {
  //   console.log(element.section);
  //   return element;
  //   //}
  // });
  console.log(`=== para = ${section} ${filterItems}    ${data[0]}`);

  if (loading) {
    <Loading />;
  }

  return (
    <>
      <Header siteTitle='Summarized Notes' />
      <Nav navItems={navItems} setSection={setSection} section={section} />
      <div>
        <h3>Using local JSON file</h3>
        {Users.map((user) => (
          <div key={user.section}> {user.title} </div>
        ))}
        <span>Key name: {filterItems}</span>
      </div>
      {loading || stories.length === 0 ? (
        <Loading />
      ) : (
        <Stories stories={stories} section={section} />
      )}
    </>
  );
}

export default App;
